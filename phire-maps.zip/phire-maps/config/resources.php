<?php

return [
    'maps' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];