<?php

return [
    'maps' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'map-locations' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];